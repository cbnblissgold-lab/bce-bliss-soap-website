const r=require('express').Router();
let products=[];
r.get('/',(q,s)=>s.json(products));
r.post('/',(q,s)=>{const p={id:Date.now(),...q.body};products.push(p);s.json(p);});
module.exports=r;