const express=require('express');const cors=require('cors');const helmet=require('helmet');
const app=express();app.use(cors());app.use(helmet());app.use(express.json());
app.get('/',(req,res)=>res.json({message:'BCE Bliss API running'}));
app.use('/api/products',require('./routes/products'));
app.listen(3000,()=>console.log('Running'));